package com.cg.jpa;
import javax.persistence.Persistence;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
public class JpaTest {
	public static void main(String[] args) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("abc");
		EntityManager em = emf.createEntityManager();
		em.getTransaction().begin();
		Trainee trainee = new Trainee();
		trainee.setTrainee_id(223344);
		trainee.setName("Spandana");
		trainee.setTrack("FullStack");
		em.persist(trainee);
		System.out.println(trainee.getName()+"Saved Successfully!");
		em.getTransaction().commit();
		
	}

}
