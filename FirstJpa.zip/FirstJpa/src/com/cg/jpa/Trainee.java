package com.cg.jpa;

import javax.persistence.*;
//annotations
@Entity
@Table(name="Trainer 123")
public class Trainee {
	@Id
     private int trainee_id;
     private String name;
     private String track;
     public Trainee(){
     }
	public int getTrainee_id() {
		return trainee_id;
	}
	public void setTrainee_id(int trainee_id) {
		this.trainee_id = trainee_id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getTrack() {
		return track;
	}
	public void setTrack(String track) {
		this.track = track;
	}
}
